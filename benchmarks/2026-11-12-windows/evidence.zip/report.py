import base64
import html
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np

ROOT = Path(__file__).resolve().parent
summary = json.loads((ROOT/'summary.json').read_text(encoding='utf-8'))
manifest = json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
order = ['tiny','tiny-directml','small','small-directml','wechat']
labels = {'tiny':'v6 tiny CPU','tiny-directml':'v6 tiny DirectML','small':'v6 small CPU',
          'small-directml':'v6 small DirectML','wechat':'微信 OCR 默认'}
short = ['tiny CPU','tiny DML','small CPU','small DML','微信 OCR']
colors = ['#4b80bf','#91b4df','#2b8565','#85bba8','#bb7049']
font_manager.fontManager.addfont('C:/Windows/Fonts/msyh.ttc')
plt.rcParams['font.family'] = font_manager.FontProperties(fname='C:/Windows/Fonts/msyh.ttc').get_name()
plt.rcParams['axes.unicode_minus'] = False

fig, axes = plt.subplots(1,3,figsize=(17,5.7),layout='constrained')
x = np.arange(5)
for ax in axes:
    ax.spines[['top','right']].set_visible(False)
    ax.set_xticks(x,short,rotation=24,ha='right')
    ax.grid(axis='y',alpha=.18)
    ax.set_axisbelow(True)
accuracy = [summary['models'][k]['accuracy']['by_category']['game']['exact_pct'] for k in order]
axes[0].bar(x,accuracy,color=colors,width=.65)
axes[0].set_ylim(0,110)
axes[0].set_title('游戏文字 ROI：完整文本正确率')
axes[0].set_ylabel('%（50 个手工标注区域）')
for i,value in enumerate(accuracy):
    axes[0].text(i,value+2,f'{value:g}%',ha='center')
for ax,key,title in [(axes[1],'game_roi_latency','混合尺寸游戏 ROI 延迟'),(axes[2],'full_frame_latency','1280 × 720 整屏延迟')]:
    values = [summary['models'][k][key]['p50_ms'] for k in order]
    upper = [summary['models'][k][key]['p95_ms']-v for k,v in zip(order,values)]
    ax.bar(x,values,color=colors,width=.65,yerr=[np.zeros(5),upper],capsize=4,error_kw={'elinewidth':1})
    ax.set_title(title)
    ax.set_ylabel('ms，P50；误差线至 P95')
    if key == 'game_roi_latency':
        ax.set_yscale('log')
        ax.set_ylim(.7,320)
    else:
        ax.set_ylim(0,370)
    for i,value in enumerate(values):
        ax.text(i,value*.84 if key=='game_roi_latency' else max(5,value-13),f'{value:.1f}',ha='center',va='top',color='white',fontsize=9)
fig.suptitle('Windows OCR 本机对比 · Ryzen 7 9800X3D / RTX 4080 SUPER',fontsize=16)
fig.supxlabel('MaaFramework 同一入口；CPU 为 ONNX Runtime 4 线程/模型，DirectML 显式选择 4080 SUPER；微信采用 vendor 默认设置。',fontsize=10)
fig.savefig(ROOT/'comparison.png',dpi=170)
fig.savefig(ROOT/'comparison.svg')
plt.close(fig)


def data_image(path):
    return 'data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode('ascii')


def escape(value):
    return html.escape(str(value))


header = []
for key in order:
    m = summary['models'][key]
    a = m['accuracy']
    header.append('<tr>'+''.join('<td>'+escape(v)+'</td>' for v in [
        labels[key], f"{a['exact']}/98 ({a['exact_pct']:.2f}%)",
        f"{a['by_category']['game']['exact']}/50",f"{a['cer_pct']:.3f}%",
        f"{m['game_roi_latency']['p50_ms']:.2f} / {m['game_roi_latency']['p95_ms']:.2f}",
        f"{m['full_frame_latency']['p50_ms']:.2f} / {m['full_frame_latency']['p95_ms']:.2f}",
        f"{m.get('cold_start_p50_ms',m['cold_to_first_roi_ms']):.1f}",
        f"{m['memory']['incremental_private_commit_mib']:.1f}",
        f"{a['full_screen_known_target_hits']}/50"
    ])+'</tr>')

accuracy_by_id = {}
for key in order:
    report = json.loads((ROOT/(key+'.json' if 'directml' in key else key+'-cpu.json')).read_text(encoding='utf-8'))
    accuracy_by_id[key] = {r['id']:r for r in report['accuracy']}

cards = []
for sample in manifest['samples']:
    correct = {}
    predicted = {}
    for key in order:
        error = next((r for r in summary['models'][key]['errors'] if r['id']==sample['id']),None)
        correct[key] = error is None
        if error is not None:
            predicted[key] = error['predicted']
        else:
            from summarize import text
            predicted[key] = text(accuracy_by_id[key][sample['id']]['lines'])
    all_correct = all(correct.values())
    rows = ''.join('<tr class="'+('ok' if correct[key] else 'bad')+'"><th>'+escape(labels[key])+
                   '</th><td>'+escape(predicted[key] or '∅')+'</td><td>'+('✓' if correct[key] else '✗')+'</td></tr>' for key in order)
    cards.append('<article data-category="'+sample['category']+'" data-perfect="'+str(int(all_correct))+'">'
                 '<div class="cardtitle">'+escape(sample['id'])+' · '+escape(sample['category'])+'</div>'
                 '<img alt="'+escape(sample['id'])+'" src="'+data_image(ROOT/sample['file'])+'">'
                 '<p><strong>标注：</strong>'+escape(sample['expected'] or '空图')+'</p><table>'+rows+'</table></article>')

fixed_rows = []
for key in order[:4]:
    name = key if 'directml' in key else key+'-cpu'
    probe = json.loads((ROOT/(name+'-fixed.json')).read_text(encoding='utf-8'))['fixed_probes']
    fixed_rows.append('<tr>'+''.join('<td>'+escape(v)+'</td>' for v in [labels[key],
        f"{probe['game-roi']['stats']['p50_ms']:.2f}",f"{probe['text-roi']['stats']['p50_ms']:.2f}",
        f"{probe['full-screen']['stats']['p50_ms']:.2f}"])+'</tr>')

page = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>微信 OCR 与 PP-OCRv6 本机实测</title><style>
body{font:15px/1.65 "Microsoft YaHei",system-ui,sans-serif;color:#203047;background:#f4f6f9;margin:0}main{max-width:1450px;margin:auto;padding:30px 28px}h1{font-size:30px;margin-bottom:6px}h2{margin-top:34px}p{max-width:1100px}.muted{color:#607087}table{width:100%;border-collapse:collapse;background:white}td,th{border-bottom:1px solid #dce3ea;padding:9px 11px;text-align:left}thead{background:#e8edf3}a{color:#2466aa}figure{margin:24px 0;background:white;padding:12px}figure img{width:100%}.scroll{overflow:auto}.notes{background:#fff;border-left:4px solid #477dae;padding:16px 22px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(350px,1fr));gap:18px}article{padding:17px;background:white;border:1px solid #e0e5ea;border-radius:9px;overflow:hidden}article>img{display:block;max-width:100%;max-height:120px;min-height:24px;margin:14px 0;image-rendering:auto}article table{table-layout:fixed;font-size:13px}article th{width:130px;font-weight:500}article td{word-break:break-word}article td:last-child{width:20px}.bad{background:#fff0e9}.ok{color:#39624f}.cardtitle{font-weight:600}select,label{font-size:15px;margin:0 16px 16px 0}small{color:#596b80}code{word-break:break-all}.proof{font-family:monospace;white-space:pre-wrap}footer{margin-top:35px;color:#607087}
</style><main><h1>微信 OCR 与 PP-OCRv6 本机实测</h1>
<p class="muted">2026-11-12 · Windows 11 build 26200 · Ryzen 7 9800X3D · RTX 4080 SUPER 16 GB（驱动 617.42）· 96 GiB RAM</p>
<p><a href="https://github.com/MaaXYZ/WeChatOCR/releases/tag/v0.2.1">WeChatOCR v0.2.1 已发布</a>。微信 runtime 为 4.1.15.13 / OCR 插件 8096。PPOCR 使用 MaaCommonAssets 的 PP-OCRv6 tiny / small ONNX 模型。</p>
<div class="notes"><strong>这批样本的结论：</strong>small CPU 在准确率和速度之间最均衡；tiny CPU 最快，但漏字和易混淆字更多。微信和 small 的 ROI 完整文本正确率相同，整屏的已标注目标命中率略高。当前 MaaFramework / FastDeploy / ONNX Runtime 的 DirectML 调用链没有带来加速；固定尺寸复测结论也相同。这不是其他 PaddleOCR 后端或所有 GPU 的性能结论。</div>
<figure><img alt="准确率和延迟对比" src="__CHART__"></figure>
<h2>汇总结果</h2><div class="scroll"><table><thead><tr><th>引擎</th><th>98 条完整文本正确率</th><th>游戏 ROI 正确数</th><th>字符错误率 CER ↓</th><th>游戏 ROI P50 / P95 ms</th><th>整屏 P50 / P95 ms</th><th>进程冷启动 P50 ms</th><th>内存增量 MiB</th><th>整屏已标注目标命中</th></tr></thead><tbody>__TABLE__</tbody></table></div>
<p><small>ROI 计时使用预先裁好的内存图像，包含检测、识别、MaaFramework 调用及结果取回。游戏 ROI 50 个，每个计时 5 次；整屏 5 张 1280×720 图，每张预热后计时 15 次。98 条不含 4 张空图，所有配置对空图均未报文字。内存为包含整屏推理的进程树峰值 Windows private commit 减基线，未包含 GPU VRAM。显存用量在 WDDM 查询下为 N/A，未估算。</small></p>
<h2>方法与边界</h2><ul><li>50 个真实游戏 ROI 来自 MaaFramework 的 PipelineSmoking 和 hbr_battle 测试资源中的 4 张截图；另有 16 条已知文本 × 3 种字体/小字/模糊条件。合成变体不是独立场景样本。</li><li>人工转录和裁剪在模型推理前固定。Unicode NFKC 后忽略空白，保留大小写、标点和字符区别；碎片框按相同行规则还原从左到右顺序。完整匹配才计正确，CER 采用逐字符编辑距离，不使用引擎置信度当准确率。</li><li>所有引擎走 MaaFramework 同一入口，threshold=0，不设置 expected 或 replace。PPOCR CPU 每个模型配置 4 线程；DirectML 显式选择 DXGI 0 号 RTX 4080 SUPER；微信使用 vendor 默认设置，未强制或证明其内部计算设备。</li><li>准确率为这批小样本的描述统计，不能外推为通用 OCR 排行。全屏“目标命中”只衡量已标注的 50 个目标，不是完整全屏 precision/recall 或 ICDAR 检测分数。匹配规则为识别框覆盖目标框至少 25%，对应文字中含预期文本。</li><li>热调用排除首次模型加载与每张整屏的首轮；进程冷启动重复 5 次，计 Resource 创建至首个 ROI 返回，文件及驱动缓存保持系统自然状态，未重启或清空 OS 缓存。</li><li>GPU 已由 DXGI 枚举、DML provider 日志及 NVIDIA 测试进程记录核对。没有把 DirectML 设备选到集显；此处未进行后端优化或调参。依赖版本：ONNX Runtime 1.29.0、DirectML 1.15.4，驱动 617.42。</li></ul>
<h2>固定尺寸复核</h2><p>每个输入预热后连续重复 40 次，表内为 P50 ms。用于核对混合尺寸测试中的 DirectML 延迟；全部与主测试串行执行。</p><table><thead><tr><th>引擎</th><th>同一游戏 ROI</th><th>同一合成文字 ROI</th><th>同一 HBR 整屏</th></tr></thead><tbody>__FIXED__</tbody></table>
<h2>逐条对比</h2><p><label><input type="checkbox" id="all">显示全部样本（默认只显示至少一个配置出错的样本）</label><select id="category"><option value="">所有类别</option><option value="game">真实游戏 ROI</option><option value="synthetic-clean">合成清晰</option><option value="synthetic-small">合成小字</option><option value="synthetic-blur">合成模糊</option><option value="blank">空图</option></select><span id="count"></span></p><div class="grid">__CARDS__</div>
<h2>复现与数据</h2><p>同目录包含 <code>manifest.json</code>、102 张裁剪/生成样本、<code>bench.py</code>、<code>summarize.py</code>、各配置完整 JSON、固定尺寸记录、5 次进程冷启动记录、模型 SHA-256 和设备枚举。原始截图来自本机 MaaFramework 测试资源，模型与微信 runtime 不复制进证据包。</p><p>模型与字典大小：tiny 5.984 MiB，small 29.673 MiB。本机微信 OCR 插件目录为 49.492 MiB，SDK Windows 压缩包约 414 KiB；微信主程序与其他 runtime 依赖未计入，部署尺寸不能直接当作独立模型尺寸比较。</p><p>冻结标注 SHA-256：<code>__HASH__</code></p><p><a href="https://github.com/MaaXYZ/MaaCommonAssets/tree/dabcd4681ac990dc4361de26416d986abd80e4aa/OCR/ppocr_v6">模型来源与固定 commit</a> · <a href="https://github.com/MaaXYZ/MaaFramework/commit/2df6f033aa4dd45ff1f2ec292a18ebc2b8eebc8f">MaaFramework 构建 commit</a> · <a href="https://github.com/MaaXYZ/WeChatOCR/releases/tag/v0.2.1">正式 SDK 发布包</a></p><footer>所有数字均来自此机实际运行；CPU、GPU 配置在独立进程中依次运行。原始输出与失误样本均保留。</footer>
<script>function filter(){let n=0;for(const c of document.querySelectorAll('article')){let ok=(!document.getElementById('category').value||c.dataset.category===document.getElementById('category').value)&&(document.getElementById('all').checked||c.dataset.perfect==='0');c.hidden=!ok;if(ok)n++}document.getElementById('count').textContent=n+' 个样本'}document.getElementById('all').onchange=filter;document.getElementById('category').onchange=filter;filter();</script></main></html>'''
page = page.replace('__CHART__',data_image(ROOT/'comparison.png')).replace('__TABLE__',''.join(header)).replace('__FIXED__',''.join(fixed_rows)).replace('__CARDS__',''.join(cards)).replace('__HASH__',summary['manifest_sha256'])
(ROOT/'report.html').write_text(page,encoding='utf-8')
print('Created report.html, comparison.png and comparison.svg')
