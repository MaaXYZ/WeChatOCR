import os
import collections
import hashlib
import html
import json
from pathlib import Path
import re
import statistics
import unicodedata

ROOT = Path(__file__).resolve().parent


def normalized(text):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', text))


def distance(left, right):
    row = list(range(len(right)+1))
    for i, a in enumerate(left, 1):
        current = [i]
        for j, b in enumerate(right, 1):
            current.append(min(current[-1]+1, row[j]+1, row[j-1]+(a != b)))
        row = current
    return row[-1]


def text(lines):
    rows = []
    for line in sorted(lines, key=lambda value: value['box'][1]+value['box'][3]/2):
        x, y, w, h = line['box']
        center = y+h/2
        match = next((row for row in rows if abs(row['center']-center) <= .5*min(row['height'],h)), None)
        if match is None:
            rows.append({'center':center, 'height':h, 'lines':[line]})
        else:
            match['lines'].append(line)
    return ''.join(line['text'] for row in rows for line in sorted(row['lines'], key=lambda value:value['box'][0]))


def coverage(box, target):
    x, y, w, h = box
    gx, gy, gw, gh = target
    area = max(0, min(x+w,gx+gw)-max(x,gx))*max(0,min(y+h,gy+gh)-max(y,gy))
    return area/(gw*gh)


def metrics(rows):
    total = len(rows)
    characters = sum(len(normalized(row['expected'])) for row in rows)
    edits = sum(row['edits'] for row in rows)
    return dict(n=total, exact=sum(row['correct'] for row in rows),
                exact_pct=round(100*sum(row['correct'] for row in rows)/total, 2) if total else None,
                characters=characters, edits=edits, cer_pct=round(100*edits/characters, 3) if characters else None,
                detected=sum(bool(row['lines']) for row in rows))


def main():
    manifest = json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    summary = dict(manifest_sha256=hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest(),
                   hardware='Windows 11 build 26200; AMD Ryzen 7 9800X3D (8C/16T); 96 GiB installed RAM; RTX 4080 SUPER.',
                   runtime='WeChat 4.1.15.13 / OCR plugin 8096; SDK v0.2.1 official Windows release.',
                   method='50 game ROIs from two games + 48 generated text images + 4 blank images. Full detection+recognition through MaaFramework; threshold=0; no expected or replacement filtering. Unicode NFKC and whitespace removal; case and punctuation retained. Read fragmented lines in spatial row/left-to-right order using the same rule for all models. Five timed repeats per pre-cropped ROI; 15 per full screen. Separate model processes. PPOCR ONNX Runtime CPU 4 threads per model or DirectML device 0 (RTX 4080 SUPER); WeChat vendor defaults; all images preloaded. Memory is incremental process-tree Windows private commit including full-screen inference, not GPU VRAM.',
                   models={})
    for engine in ['tiny','small','wechat','tiny-directml','small-directml']:
        file = ROOT / (f'{engine}.json' if 'directml' in engine else f'{engine}-cpu.json')
        if not file.exists():
            continue
        report = json.loads(file.read_text(encoding='utf-8'))
        assert report['manifest_sha256'] == summary['manifest_sha256']
        for row in report['accuracy']:
            row['predicted'] = text(row['lines'])
            row['correct'] = normalized(row['predicted']) == normalized(row['expected'])
            row['edits'] = distance(normalized(row['predicted']), normalized(row['expected']))
        score = metrics([r for r in report['accuracy'] if r['category'] != 'blank'])
        score['by_category'] = {category: metrics([r for r in report['accuracy'] if r['category'] == category])
                                for category in sorted(set(r['category'] for r in report['accuracy']))}
        blanks = [r for r in report['accuracy'] if r['category'] == 'blank']
        score['blank_false_positives'] = sum(bool(r['lines']) for r in blanks)
        score['blank_count'] = len(blanks)
        full_by_path = {f['path']: f for f in report['full_frames']}
        targets = []
        for sample in manifest['samples']:
            if sample['category'] != 'game':
                continue
            frame = full_by_path[sample['source']]
            candidates = [line for line in frame['lines'] if coverage(line['box'], sample['source_box']) >= .25]
            predicted = text(candidates)
            targets.append(dict(id=sample['id'], expected=sample['expected'], predicted=predicted,
                                hit=normalized(sample['expected']) in normalized(predicted), candidates=candidates))
        score['full_screen_known_target_hits'] = sum(t['hit'] for t in targets)
        score['full_screen_known_target_count'] = len(targets)
        score['full_screen_known_target_hit_pct'] = round(100*sum(t['hit'] for t in targets)/len(targets), 2)
        score['full_screen_target_details'] = targets
        model = dict(accuracy=score, roi_latency=report['roi_stats'],
                      game_roi_latency=report['roi_stats_by_category']['game'],
                      full_frame_latency=report['full_frame_stats'], memory=report['memory'],
                      cold_to_first_roi_ms=report['cold_to_first_roi_ms'], errors=[r for r in report['accuracy'] if not r['correct']],
                      roi_cpu_seconds=report['roi_cpu_seconds'], roi_wall_seconds=report['roi_wall_seconds'])
        if engine != 'wechat':
            folder = Path(os.environ.get('WCO_BENCH_MODELS_DIR', str(ROOT/'MaaCommonAssets/OCR/ppocr_v6')))/engine.split('-')[0]
            model['files'] = {p.name: {'bytes': p.stat().st_size, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
                               for p in folder.iterdir() if p.suffix in ('.onnx','.txt')}
            model['model_mib'] = round(sum(f['bytes'] for f in model['files'].values())/2**20, 3)
        summary['models'][engine] = model
    summary['sources'] = {'MaaCommonAssets':'https://github.com/MaaXYZ/MaaCommonAssets/tree/dabcd4681ac990dc4361de26416d986abd80e4aa/OCR/ppocr_v6',
                          'WeChatOCR':'https://github.com/MaaXYZ/WeChatOCR/releases/tag/v0.2.1',
                          'MaaFramework':'https://github.com/MaaXYZ/MaaFramework/commit/2df6f033aa4dd45ff1f2ec292a18ebc2b8eebc8f'}
    summary['runtime_versions'] = {'ONNX Runtime':'1.29.0','DirectML':'1.15.4+241025-1615.1.dml-1.15.fac7597',
                                   'NVIDIA driver':'617.42','SDK release commit':'29414b1f82c61428b7ac8892bd2e5a25efa3ca6c',
                                   'SDK Windows archive SHA256':'ab9f07b935fdb5e89b144b432ca36752cb0d92d2be915f3a0c4fe984cc47480d'}
    summary['adapters'] = json.loads((ROOT/'adapters.json').read_text(encoding='utf-8'))
    summary['wechat_deployment'] = {'sdk_windows_zip_bytes':423565,'local_ocr_plugin_bytes':51896625,
                                    'wxocr_dll_bytes':24486952,'mmmojo_dll_bytes':2499176,
                                    'host_install_not_included':True}
    if (ROOT/'cold-starts.json').exists():
        cold = json.loads((ROOT/'cold-starts.json').read_text(encoding='utf-8'))
        for name, values in cold.items():
            summary['models'][name]['cold_start_runs_ms'] = values
            summary['models'][name]['cold_start_p50_ms'] = round(statistics.median(values),3)
    (ROOT/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    for name, model in summary['models'].items():
        print(name, json.dumps({k:v for k,v in model.items() if k not in ('accuracy','errors','files')},ensure_ascii=False))
        print('ACCURACY', json.dumps({k:v for k,v in model['accuracy'].items() if k!='full_screen_target_details'},ensure_ascii=False))
        print('ERRORS',json.dumps([{k:r[k] for k in ('id','expected','predicted')} for r in model['errors']],ensure_ascii=False))


if __name__ == '__main__':
    main()
