import argparse
import collections
import ctypes
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import statistics
import subprocess
import sys
import threading
import time

os.environ['OPENBLAS_NUM_THREADS'] = '1'
import numpy as np
from PIL import Image
import psutil

ROOT = Path(__file__).resolve().parent
FW = Path(os.environ.get('MAAFW_SOURCE_DIR', 'E:/Code/MaaFramework-wechat-windows'))
sys.path.insert(0, os.environ.get('MAAFW_PYTHON_PATH', str(FW / 'source/binding/Python')))
os.environ.setdefault('MAAFW_BINARY_PATH', str(FW / 'build-windows/stage/bin'))

from maa.library import Library
from maa.pipeline import JOCR, JRecognitionType
from maa.resource import Resource
from maa.tasker import Tasker


class Monitor:
    def __init__(self):
        self.process = psutil.Process()
        self.done = threading.Event()
        self.cpu = {}
        self.peak_rss = 0
        self.peak_private = 0
        self.peak_threads = 0
        self.snapshot()
        self.baseline_rss = self.peak_rss
        self.baseline_private = self.peak_private
        self.thread = threading.Thread(target=self.run, daemon=True)

    def snapshot(self):
        rss = private = threads = 0
        processes = [self.process, *self.process.children(recursive=True)]
        for process in processes:
            try:
                with process.oneshot():
                    memory = process.memory_info()
                    rss += memory.rss
                    private += getattr(memory, 'private', memory.vms)
                    threads += process.num_threads()
                    cpu = process.cpu_times()
                    self.cpu[(process.pid, process.create_time())] = cpu.user + cpu.system
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        self.peak_rss = max(self.peak_rss, rss)
        self.peak_private = max(self.peak_private, private)
        self.peak_threads = max(self.peak_threads, threads)

    def run(self):
        while not self.done.wait(.02):
            self.snapshot()

    def start(self):
        self.thread.start()

    def stop(self):
        self.done.set()
        self.thread.join()
        self.snapshot()


def pixels(path):
    return np.array(Image.open(path).convert('RGB'))[:, :, ::-1].copy()


def stats(values):
    return {'n': len(values), 'p50_ms': round(statistics.median(values), 3),
            'p95_ms': round(float(np.percentile(values, 95)), 3),
            'mean_ms': round(statistics.mean(values), 3), 'min_ms': round(min(values), 3),
            'max_ms': round(max(values), 3)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--engine', choices=['tiny', 'small', 'wechat'], required=True)
    parser.add_argument('--device', choices=['cpu', 'directml'], default='cpu')
    parser.add_argument('--device-id', type=int, default=0)
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--full-repeats', type=int, default=15)
    parser.add_argument('--cold-only', action='store_true')
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--diagnostic', action='store_true')
    parser.add_argument('--fixed-probe', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    samples = manifest['samples']
    sample_images = {s['id']: pixels(ROOT / s['file']) for s in samples}
    full_images = {p: pixels(FW / 'test' / p.replace('\\', '/').split('/test/', 1)[1]) for p in manifest['full_frames']}

    Tasker.set_log_dir('')
    Tasker.set_stdout_level(4 if args.diagnostic else 0)
    save_draw = ctypes.c_uint8(0)
    setter = Library.framework().MaaGlobalSetOption
    setter.argtypes = [ctypes.c_int32, ctypes.c_void_p, ctypes.c_uint64]
    setter.restype = ctypes.c_uint8
    assert setter(2, ctypes.byref(save_draw), 1)
    assert setter(6, ctypes.byref(save_draw), 1)

    bundle = ROOT / 'bundles' / args.engine
    (bundle / 'pipeline').mkdir(parents=True, exist_ok=True)
    (bundle / 'pipeline/ocr.json').write_text(json.dumps({'OCR': {
        'recognition': {'type': 'OCR', 'param': {'engine': 'WeChatOCR' if args.engine == 'wechat' else 'Default'}}
    }}), encoding='utf-8')
    if args.engine != 'wechat':
        model = bundle / 'model/ocr'
        model.mkdir(parents=True, exist_ok=True)
        for name in ['det.onnx', 'rec.onnx', 'keys.txt']:
            source = Path(os.environ.get('WCO_BENCH_MODELS_DIR', str(ROOT / 'MaaCommonAssets/OCR/ppocr_v6'))) / args.engine / name
            if not (model / name).exists():
                shutil.copy2(source, model / name)

    monitor = Monitor()
    monitor.start()
    cold_started = time.perf_counter()
    resource = Resource()
    assert resource.use_cpu() if args.device == 'cpu' else resource.use_directml(args.device_id)
    if args.engine == 'wechat':
        assert resource.configure_wechat_ocr(), 'WeChat runtime creation failed'
    assert resource.post_bundle(bundle).wait().succeeded, 'model bundle load failed'
    tasker = Tasker()
    assert Library.framework().MaaTaskerBindResource(tasker._handle, resource._handle)
    config = JOCR(engine='WeChatOCR' if args.engine == 'wechat' else 'Default', threshold=0, order_by='Vertical')

    def recognize(image):
        start = time.perf_counter()
        detail = tasker.post_recognition(JRecognitionType.OCR, config, image).wait().get()
        elapsed = (time.perf_counter() - start) * 1000
        if not detail or len(detail.nodes) != 1 or not detail.nodes[0].recognition:
            raise RuntimeError('Missing native recognition details')
        recognition = detail.nodes[0].recognition
        raw = recognition.raw_detail
        if not isinstance(raw, dict) or 'all' not in raw:
            raise RuntimeError(f'Missing native OCR results: {raw}')
        return raw['all'], elapsed

    first, first_call_ms = recognize(sample_images[samples[0]['id']])
    report = dict(engine=args.engine, device=args.device, pid=os.getpid(),
                  manifest_sha256=hashlib.sha256((ROOT / 'manifest.json').read_bytes()).hexdigest(),
                  cold_to_first_roi_ms=round((time.perf_counter()-cold_started)*1000, 3),
                  first_roi_call_ms=round(first_call_ms, 3), first_roi_result=first,
                  framework_head='2df6f033aa4dd45ff1f2ec292a18ebc2b8eebc8f',
                  sdk_version='0.2.1', onnxruntime_cpu_threads=4 if args.device == 'cpu' else None,
                  directml_device_id=args.device_id if args.device == 'directml' else None,
                  method='MaaFramework post_recognition through result retrieval; images preloaded; threshold=0; no expected/replacement filters.')
    if args.fixed_probe:
        report['fixed_probes'] = {}
        for name, image in [('game-roi',sample_images['game-00']),
                            ('text-roi',sample_images['synthetic-0-00']),
                            ('full-screen',next(iter(full_images.values())))]:
            recognize(image)
            timings = [recognize(image)[1] for _ in range(40)]
            report['fixed_probes'][name] = {'stats':stats(timings),'timings_ms':timings}
    if not args.cold_only and not args.fixed_probe:
        report['accuracy'] = []
        for index, sample in enumerate(samples):
            lines, elapsed = recognize(sample_images[sample['id']])
            report['accuracy'].append(dict(id=sample['id'], category=sample['category'],
                                            expected=sample['expected'], lines=lines, first_pass_ms=round(elapsed, 3)))
            if args.preflight and index == 2:
                break
        print(f'{args.engine}/{args.device}: accuracy pass complete', flush=True)
        report['roi_timings'] = []
        order = list(range(len(samples)))
        randomizer = random.Random(20261112)
        cpu_before = sum(monitor.cpu.values())
        timed_start = time.perf_counter()
        if not args.preflight:
            for iteration in range(args.repeats):
                randomizer.shuffle(order)
                for index in order:
                    sample = samples[index]
                    _, elapsed = recognize(sample_images[sample['id']])
                    report['roi_timings'].append(dict(id=sample['id'], category=sample['category'], ms=round(elapsed, 3)))
                print(f'{args.engine}/{args.device}: ROI pass {iteration+1}/{args.repeats}', flush=True)
            monitor.snapshot()
            report['roi_cpu_seconds'] = round(sum(monitor.cpu.values()) - cpu_before, 3)
            report['roi_wall_seconds'] = round(time.perf_counter() - timed_start, 3)
            report['roi_stats'] = stats([s['ms'] for s in report['roi_timings']])
            report['roi_stats_by_category'] = {category: stats([s['ms'] for s in report['roi_timings'] if s['category'] == category])
                                                for category in sorted(set(s['category'] for s in samples))}
            report['full_frames'] = []
            for path, image in full_images.items():
                lines, cold_full_ms = recognize(image)
                timings = [recognize(image)[1] for _ in range(args.full_repeats)]
                report['full_frames'].append(dict(path=path, shape=list(image.shape), lines=lines,
                                                  first_full_ms=round(cold_full_ms, 3), timings_ms=timings,
                                                  stats=stats(timings)))
                print(f'{args.engine}/{args.device}: full frame {Path(path).name}', flush=True)
            report['full_frame_stats'] = stats([v for frame in report['full_frames'] for v in frame['timings_ms']])
    if args.diagnostic and args.device == 'directml':
        query = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory',
                                '--format=csv,noheader'], capture_output=True, text=True, check=True)
        own = {os.getpid(), *(p.pid for p in psutil.Process().children(recursive=True))}
        report['nvidia_processes'] = [line for line in query.stdout.splitlines()
                                     if line.split(',')[0].strip().isdigit() and int(line.split(',')[0].strip()) in own]
    monitor.stop()
    report['memory'] = dict(baseline_rss_mib=round(monitor.baseline_rss/2**20, 2),
                            peak_tree_rss_mib=round(monitor.peak_rss/2**20, 2),
                            incremental_rss_mib=round((monitor.peak_rss-monitor.baseline_rss)/2**20, 2),
                            baseline_private_commit_mib=round(monitor.baseline_private/2**20, 2),
                            peak_tree_private_commit_mib=round(monitor.peak_private/2**20, 2),
                            incremental_private_commit_mib=round((monitor.peak_private-monitor.baseline_private)/2**20, 2),
                            peak_tree_threads=monitor.peak_threads)
    del tasker
    assert resource.clear()
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('accuracy','roi_timings','full_frames')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
