import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import uuid


class Description(c.Structure):
    _fields_ = [('name', c.c_wchar*128), ('vendor', w.UINT), ('device', w.UINT),
                ('subsystem', w.UINT), ('revision', w.UINT),
                ('dedicated_video', c.c_size_t), ('dedicated_system', c.c_size_t),
                ('shared_system', c.c_size_t), ('luid_low', w.DWORD), ('luid_high', w.LONG), ('flags', w.UINT)]


def method(obj, index, result, *args):
    table = c.cast(obj, c.POINTER(c.POINTER(c.c_void_p))).contents
    return c.WINFUNCTYPE(result, c.c_void_p, *args)(table[index])


factory = c.c_void_p()
iid = (c.c_ubyte*16).from_buffer_copy(uuid.UUID('770aae78-f26f-4dba-a829-253c83d1b387').bytes_le)
create = c.WinDLL('dxgi').CreateDXGIFactory1
create.argtypes = [c.c_void_p, c.POINTER(c.c_void_p)]
create.restype = w.LONG
assert create(iid, c.byref(factory)) == 0
adapters = []
try:
    for index in range(32):
        adapter = c.c_void_p()
        result = method(factory, 12, w.LONG, w.UINT, c.POINTER(c.c_void_p))(factory, index, c.byref(adapter))
        if result:
            break
        try:
            description = Description()
            assert method(adapter, 10, w.LONG, c.POINTER(Description))(adapter, c.byref(description)) == 0
            adapters.append(dict(index=index, name=description.name, vendor_id=description.vendor,
                                 dedicated_video_bytes=description.dedicated_video, flags=description.flags))
        finally:
            method(adapter, 2, w.ULONG)(adapter)
finally:
    method(factory, 2, w.ULONG)(factory)
Path(__file__).with_name('adapters.json').write_text(json.dumps(adapters,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(adapters,ensure_ascii=False))
