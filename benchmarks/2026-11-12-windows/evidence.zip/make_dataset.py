import os
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent
FW = Path(os.environ.get('MAAFW_SOURCE_DIR', 'E:/Code/MaaFramework-wechat-windows'))
frames = sorted((FW / 'test/TestingDataSet/PipelineSmoking/Screenshot').glob('*.png'))
hbr = FW / 'test/pipeline/resources/BatchOcrRepro/Screenshot/hbr_battle.png'
out = ROOT / 'dataset'
out.mkdir(exist_ok=True)
samples = []


def add(identifier, category, image, text, box, source, source_box=None):
    path = out / (identifier + '.png')
    image.save(path)
    samples.append(dict(id=identifier, category=category, file=str(path.relative_to(ROOT)),
                        expected=text, gt_box=box, source=source, source_box=source_box,
                        width=image.width, height=image.height,
                        sha256=hashlib.sha256(path.read_bytes()).hexdigest()))


real = [
    (hbr, '技术模拟战', [108, 23, 150, 30]),
    (hbr, '赛季点数', [662, 35, 96, 30]),
    (hbr, '4,862,000', [855, 35, 111, 30]),
    (hbr, '99,999', [1098, 35, 87, 30]),
    (hbr, '战斗', [1150, 243, 75, 38]),
    (hbr, '无尽模式', [1043, 472, 146, 36]),
    (hbr, '积分榜', [793, 640, 83, 29]),
    (hbr, '技术卡', [1103, 640, 79, 29]),
    (hbr, '奖励', [60, 654, 38, 23]),
    (hbr, '任务', [165, 654, 42, 23]),
    (hbr, '奖章扭蛋', [254, 654, 78, 23]),
    (hbr, '游玩指南', [358, 654, 83, 23]),
    (hbr, '第七赛季 -2026 SUMMERⅡ-', [61, 392, 501, 43]),
    (hbr, '2026/08/12 13:00', [64, 454, 185, 28]),
    (hbr, '2026/10/28 12:59', [280, 454, 183, 28]),
    (hbr, '期间举办', [468, 454, 89, 28]),
    (frames[0], 'RETURN TO THE FUTURE', [305, 101, 685, 50]),
    (frames[0], '重返未来1999', [394, 247, 490, 140]),
    (frames[0], 'REVERSE', [478, 427, 324, 25]),
    (frames[0], 'START', [587, 522, 98, 26]),
    (frames[12], '13/13', [973, 23, 61, 24]),
    (frames[12], '3370', [1151, 23, 51, 24]),
    (frames[12], '利齿市集', [711, 138, 83, 25]),
    (frames[12], '微尘钟楼', [488, 202, 86, 27]),
    (frames[12], '荒原古厅', [651, 239, 87, 27]),
    (frames[12], '如愿甘泉', [771, 310, 90, 27]),
    (frames[12], '古厅定位', [1168, 146, 88, 30]),
    (frames[12], '高视角', [1175, 240, 71, 30]),
    (frames[12], '购入', [1187, 338, 49, 29]),
    (frames[12], '布局方案', [1165, 429, 96, 31]),
    (frames[12], '放置角色', [1164, 568, 97, 31]),
    (frames[12], '荒原编辑', [1164, 666, 97, 30]),
    (frames[32], '326K', [822, 23, 58, 24]),
    (frames[32], '6870', [987, 23, 49, 24]),
    (frames[32], '1455', [1145, 23, 52, 24]),
    (frames[32], '63/197', [1181, 168, 75, 24]),
    (frames[32], '邮件', [56, 202, 46, 27]),
    (frames[32], '任务', [56, 283, 46, 27]),
    (frames[32], '仓库', [56, 361, 46, 27]),
    (frames[32], '银行', [56, 457, 46, 29]),
    (frames[32], '不休荒原', [940, 411, 95, 23]),
    (frames[32], '角色', [1100, 427, 48, 23]),
    (frames[32], '征集', [950, 514, 58, 23]),
    (frames[32], '入场', [1114, 279, 64, 31]),
    (frames[32], 'SHOW', [976, 299, 100, 27]),
    (frames[32], 'ENTER', [1040, 270, 52, 16]),
    (frames[32], '箱中巡游', [192, 73, 62, 16]),
    (frames[32], '11d', [100, 325, 32, 22]),
    (frames[32], '它们都是静止的，因为任何一滴雨在它的下坠过程中都有一个暂时的位置～', [286, 637, 705, 28]),
    (frames[32], 'They are motionless at the instants of time which constitute the falling process.', [268, 668, 744, 26]),
]

for index, (source, text, box) in enumerate(real):
    frame = Image.open(source).convert('RGB')
    x, y, w, h = box
    left, top = max(0, x - 2), max(0, y - 2)
    crop = frame.crop((left, top, min(frame.width, x + w + 2), min(frame.height, y + h + 2)))
    add(f'game-{index:02d}', 'game', crop, text, [x-left, y-top, w, h], str(source), box)

phrases = [
    '剿灭作战 已完成', '理智 135/135', '龙门币 1,234,567', '开始行动',
    '任务奖励 已领取', '战斗失败 请重试', '自动部署 代理指挥', '危机合约 第十三赛季',
    '博士 Lv.120', '设置 / 返回 / 确认', 'OCR Test O0I1l 12345', 'Version v6.0.1-beta',
    'HP 8,192 / 10,000', '世界你好，欢迎回来！', '繁體中文：領取獎勵', '获取60合成玉',
]
for variant in range(3):
    font = ImageFont.truetype('C:/Windows/Fonts/simsun.ttc' if variant == 1 else 'C:/Windows/Fonts/msyh.ttc',
                             16 if variant == 1 else 24 if variant == 0 else 36)
    for index, text in enumerate(phrases):
        bounds = font.getbbox(text)
        w, h = bounds[2]-bounds[0], bounds[3]-bounds[1]
        image = Image.new('RGB', (w+24, h+24), (245, 245, 245) if variant == 0 else (26, 32, 44))
        ImageDraw.Draw(image).text((12-bounds[0], 12-bounds[1]), text, font=font,
                                  fill=(20, 20, 20) if variant == 0 else (195, 201, 210))
        box = [12, 12, w, h]
        if variant == 2:
            scale = 0.65
            image = image.resize((round(image.width*scale), round(image.height*scale)), Image.Resampling.BICUBIC)
            image = image.filter(ImageFilter.GaussianBlur(0.45))
            box = [round(v*scale) for v in box]
        add(f'synthetic-{variant}-{index:02d}', ['synthetic-clean', 'synthetic-small', 'synthetic-blur'][variant],
            image, text, box, f'Pillow text / font={font.path} / variant={variant}')

for index, color in enumerate(['white', 'black', '#202b3c', '#b1b4ba']):
    add(f'blank-{index}', 'blank', Image.new('RGB', (320, 96), color), '', None, 'uniform generated background')

manifest = dict(method='Frozen before model inference; game ROIs manually transcribed from source screenshots.',
                normalization='Unicode NFKC; remove all whitespace; preserve case and punctuation.',
                samples=samples, full_frames=[str(hbr), str(frames[0]), str(frames[12]), str(frames[21]), str(frames[32])])
(ROOT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
label_font = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 13)
for page in range(2):
    sheet = Image.new('RGB', (1600, 7*100), '#dddddd')
    draw = ImageDraw.Draw(sheet)
    for j, sample in enumerate(samples[page*28:min(50,(page+1)*28)]):
        col, row = j % 4, j // 4
        x, y = col*400, row*100
        img = Image.open(ROOT / sample['file'])
        img.thumbnail((390, 58))
        sheet.paste(img, (x+5, y+3))
        draw.text((x+4, y+64), sample['id']+' '+sample['expected'], font=label_font, fill='black')
    sheet.save(ROOT / f'labels-{page}.png')
print('Frozen samples:', len(samples), 'game:', len(real), 'manifest SHA256:', hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest())
