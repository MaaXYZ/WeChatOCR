import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
output = {}
for model in ('tiny','small','tiny-directml','small-directml','wechat'):
    engine = model.split('-')[0]
    device = 'directml' if 'directml' in model else 'cpu'
    output[model] = []
    for iteration in range(5):
        report = root/f'cold-{model}-{iteration}.json'
        completed = subprocess.run([sys.executable,'-X','utf8',str(root/'bench.py'),
                                    '--engine',engine,'--device',device,'--device-id','0',
                                    '--cold-only','--output',str(report)], capture_output=True, text=True, encoding='utf-8')
        if completed.returncode:
            raise RuntimeError(completed.stdout+completed.stderr)
        output[model].append(json.loads(report.read_text(encoding='utf-8'))['cold_to_first_roi_ms'])
    print(model, output[model],flush=True)
(root/'cold-starts.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
